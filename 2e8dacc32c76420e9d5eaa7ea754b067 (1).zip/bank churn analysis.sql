use bank_crm;
-- Objective Questions:
-- 1.What is the distribution of account balances across different regions?
   select G.GeographyID,G.GeographyLocation,SUM(B.Balance)as total_balance from bank_churn B
    JOIN customer_info C on C.Customer_ID=B.Customer_ID
   JOIN geography G on G.GeographyID = C.GeographyID
   group by G.GeographyID,G.GeographyLocation;
   
-- 2.	Identify the top 5 customers with the highest Estimated Salary in the last quarter of the year.
select Customer_ID,Surname,EstimatedSalary from customer_info
where SUBSTR(Bank_DOJ,4,2) IN(10,11,12)
order by EstimatedSalary desc
limit 5;

-- 3.	Calculate the average number of products used by customers who have a credit card.
select AVG(NumOfProducts)as Average_Number_Of_Products from bank_churn
where Has_creditcard=1;

-- 4.	Determine the churn rate by gender for the most recent year in the dataset.
WITH most_recent_year as(
     select C.GenderID, G.GenderCategory, C.Customer_ID,
     B.Exited,
     C.Bank_DOJ from customer_info C
    JOIN gender G ON G.GenderID=C.GenderID
    JOIN bank_churn B ON B.Customer_ID= C.Customer_ID
    )
    select GenderCategory, ROUND(SUM(CASE when Exited=1 
    then 1 else 0 
    END)*100/count(*),2) as Churn_Rate, YEAR(Bank_DOJ)
    AS  Year
    from most_recent_year
    where year(Bank_DOJ)= (select max(year(Bank_DOJ)) from 
    customer_info)
    group by GenderCategory, Year;

-- 5.	Compare the average credit score of customers who have exited and those who remain.
select 
AVG(CASE WHEN Exited='1' THEN CreditScore END)as avg_exited,
AVG(CASE WHEN Exited='0' THEN CreditScore END)as avg_remaining
from bank_churn;

-- 6.	Which gender has a higher average estimated salary, and how does it relate to the number of active accounts?
select C.GenderID,G.GenderCategory,ROUND(AVG(C.EstimatedSalary),2)as avg_estimated_salary from customer_info C
JOIN gender G ON G.GenderID=C.GenderID
group by C.GenderID,G.GenderCategory
order by avg_estimated_salary desc;
-- Count of Active Customers
select count(B.IsActiveMember)as Active_Members,C.GenderID,G.GenderCategory from bank_churn B
JOIN customer_info C ON C.Customer_ID=B.Customer_ID
JOIN gender G ON G.GenderID=C.GenderID
where B.IsActiveMember=1
group by C.GenderID,G.GenderCategory;

-- 7.	Segment the customers based on their credit score and identify the segment with the highest exit rate. (SQL)
select 
    CASE 
        WHEN CreditScore BETWEEN '800' and 850 THEN 'Excellent'
        WHEN CreditScore BETWEEN '740' and '799' THEN 'Very Good'
        WHEN CreditScore BETWEEN '670' and '739' THEN 'Good'
        WHEN CreditScore BETWEEN '580' and '669' THEN 'Fair'
        WHEN CreditScore BETWEEN '300' and '579' THEN 'Poor'
    END AS CreditSegment,
    COUNT(*) AS TotalCustomers,
    SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) AS ExitedCustomers,
    ROUND((SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) * 1.0 / COUNT(*)) * 100, 2) AS ExitRate
from bank_churn
group by CreditSegment
order by ExitRate DESC;

-- 8.	Find out which geographic region has the highest number of active customers with a tenure greater than 5 years. (SQL)

select C.GeographyID,G.GeographyLocation,COUNT(B.IsActiveMember)AS Active_Customers from  customer_info C
JOIN bank_churn B ON B.Customer_ID= C.Customer_ID
JOIN geography G ON G.GeographyID= C.GeographyID
where B.IsActiveMember=1 and B.Tenure>5
group by C.GeographyID,G.GeographyLocation
order by Active_Customers desc;

-- 9.	What is the impact of having a credit card on customer churn, based on the available data?
select
    CASE 
        WHEN Has_creditcard = 1 THEN 'Has Credit Card'
        ELSE 'No Credit Card'
    END AS CreditCardStatus,
    COUNT(*) AS TotalCustomers,
    SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) AS ExitedCustomers,
    ROUND((SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) * 1.0 / COUNT(*)) * 100, 2) AS ChurnRate
from bank_churn
group by CreditCardStatus;

-- 10.	For customers who have exited, what is the most common number of products they have used?
select NumOfProducts, COUNT(Customer_ID) AS
ProductUsageCount
from bank_churn
where Exited = 1
group by NumOfProducts
order by ProductUsageCount DESC;

-- 11.	Examine the trend of customers joining over time 
-- and identify any seasonal patterns (yearly or monthly). Prepare the data through SQL and then visualize it.

SELECT 
    EXTRACT(YEAR FROM CAST(Bank_DOJ AS DATE)) AS Year,
    EXTRACT(MONTH FROM CAST(Bank_DOJ AS DATE)) AS Month,
    COUNT(*) AS CustomersJoined
FROM 
    customer_info
GROUP BY 
    EXTRACT(YEAR FROM CAST(Bank_DOJ AS DATE)),
    EXTRACT(MONTH FROM CAST(Bank_DOJ AS DATE))
ORDER BY 
    Year, Month;
    
-- 12.	Analyze the relationship between the number of products and the account balance for customers who have exited.
select NumOfProducts,COUNT(Customer_ID) as ExitedCustomers,ROUND(AVG(Balance),2) as AverageBalance from bank_churn
where Exited=1
group by NumOfProducts;

-- 15.	Using SQL, write a query to find out the gender-wise average income of 
--     males and females in each geography id. Also, rank the gender according to the average value. (SQL)
SELECT GeographyID, G.GenderCategory, ROUND(AVG(C.EstimatedSalary),2) AS AverageIncome,
RANK() OVER (PARTITION BY GeographyID ORDER BY AVG(C.EstimatedSalary) DESC) AS GenderRank
from customer_info C
JOIN Gender G ON C.GenderID = G.GenderID
group by GeographyID, G.GenderCategory
order by GeographyID, GenderRank;

-- 16.	Using SQL, write a query to find out the average tenure of the people who have exited in each age bracket (18-30, 30-50, 50+).
select ROUND(AVG(CASE WHEN C.Age BETWEEN '18' and '30' THEN B.Tenure END),2)AS Young,
 ROUND(AVG(CASE WHEN C.Age BETWEEN '30' and '50' THEN B.Tenure END),2) AS MIDDLE,
 ROUND(AVG(CASE WHEN C.Age>'50' THEN B.Tenure  END),2)AS Seniors from customer_info C
 JOIN bank_churn B on B.Customer_ID=C.Customer_ID
 where B.Exited=1;

-- 17.	Is there any direct correlation between salary and the balance of the customers? And is it different for people who have exited or not?
-- Exit customers
select C.Customer_ID,C.EstimatedSalary as Salary,B.Balance from bank_churn B
JOIN customer_info C ON C.Customer_ID=B.Customer_ID
where B.Exited=1;
-- Retained Customers
select C.Customer_ID,C.EstimatedSalary as Salary,B.Balance from bank_churn B
JOIN customer_info C ON C.Customer_ID=B.Customer_ID
where B.Exited=0;

-- 18.	Is there any correlation between the salary and the Credit score of customers?
select C.Customer_ID,C.EstimatedSalary as Salary,B.CreditScore from bank_churn B
JOIN customer_info C ON C.Customer_ID=B.Customer_ID;

-- 19.	Rank each bucket of credit score as per the number of customers who have churned the bank.
WITH customer_credit_segment as(
select 
CASE 
WHEN CreditScore BETWEEN '800' and 850 THEN 'Excellent'
WHEN CreditScore BETWEEN '740' and '799' THEN 'Very Good'
WHEN CreditScore BETWEEN '670' and '739' THEN 'Good'
 WHEN CreditScore BETWEEN '580' and '669' THEN 'Fair'
 WHEN CreditScore BETWEEN '300' and '579' THEN 'Poor'
 END AS CreditSegment,
 COUNT(*) AS TotalCustomers from bank_churn
  where Exited=1
  group by CreditSegment
  )
  select CreditSegment,TotalCustomers,DENSE_RANK() 
  OVER(order by TotalCustomers desc) from 
 customer_credit_segment;   

-- 20.	According to the age buckets find the number of customers who have a credit card. 
-- Also retrieve those buckets that have lesser than average number of credit cards per bucket.
WITH AgeBuckets AS (
  SELECT 
  CASE 
        WHEN Age < 25 THEN 'Youth (Under 25)'
        WHEN Age BETWEEN 25 AND 35 THEN 'Young Adults (25-35)'
        WHEN Age BETWEEN 36 AND 50 THEN 'Middle Age (36-50)'
        ELSE 'Senior (Above 50)'
  END AS AgeBucket,
  COUNT(*) AS CreditCardCustomers
  FROM customer_info C
  JOIN bank_churn B ON B.Customer_ID=C.Customer_ID
  WHERE B.Has_creditcard = 1 
  GROUP BY AgeBucket
),
averagecreditcards AS (
  SELECT AVG(CreditCardCustomers) AS AverageCreditCardCustomers
  FROM AgeBuckets
)
SELECT A.AgeBucket, A.CreditCardCustomers
FROM AgeBuckets A,averagecreditcards AC
WHERE A.CreditCardCustomers < AC.AverageCreditCardCustomers;

-- 21.	Rank the Locations as per the number of people who have churned the bank and average balance of the customers.
select G.GeographyLocation,COUNT(*) as ChurnedCustomers,ROUND(AVG(B.Balance),2)as AverageBalance,
DENSE_RANK() OVER(order by COUNT(*) desc) as ChurnRank,
DENSE_RANK() OVER(order by AVG(B.Balance) desc)as BalanceRank from bank_churn B
 JOIN customer_info C ON C.Customer_ID=B.Customer_ID
 JOIN geography G ON G.GeographyID=C.GeographyID
 where B.Exited=1
group by G.GeographyLocation; 

-- 22.	As we can see that the “CustomerInfo” table has the CustomerID and Surname, now if we have to join it with a table where the primary key is also a combination of CustomerID and Surname, 
-- come up with a column where the format is “CustomerID_Surname”.
SELECT CONCAT(CustomerID,”_”, Surname) as CustomerID_Surname FROM CustomerInfo; 

-- 23.	Without using “Join”, can we get the “ExitCategory” from ExitCustomers table to Bank_Churn table? If yes do this using SQL.
select bc.Customer_Id,bc.Balance,bc.CreditScore,bc.Exited,bc.HasCrCard,
bc.IsActiveMember,bc.NumOfProducts,bc.Tenure,
(SELECT ec.ExitCategory 
FROM exitcustomer ec 
WHERE ec.Exit_ID = bc.Exited) AS ExitCategory
FROM bank_churn bc;

-- 25.	Write the query to get the customer IDs, their last name, and whether they are active or not for the customers whose surname ends with “on”.
select C.Customer_ID,C.Surname,B.IsActiveMember from 
customer_info C
JOIN bank_churn B ON B.Customer_ID= C.Customer_ID
where C.Surname LIKE '%on';

-- 26.	Can you observe any data disrupency in the Customer’s data? As a hint it’s present in the IsActiveMember and Exited columns. 
-- One more point to consider is that the data in the Exited Column is absolutely correct and accurate.
select * from bank_churn
where IsActiveMember=1 and Exited=1;

-- Subjective Questions:

-- 1.	Customer Behavior Analysis: What patterns can be observed in the spending habits of long-term customers compared to new customers, 
-- and what might these patterns suggest about customer loyalty?

select CASE 
WHEN B.Tenure>=5 THEN 'Long-Term'
ELSE 'New'
END AS CustomerType,
COUNT(C.Customer_ID) AS CustomerCount,
ROUND(AVG(C.EstimatedSalary),2) AS AvgSalary,
ROUND(AVG(B.Balance),2) AS AvgBalance,
ROUND(AVG(C.EstimatedSalary-B.Balance),2) AS AvgSpending
from bank_churn B
JOIN customer_info C ON C.Customer_ID=B.Customer_ID
group by CustomerType;

-- 2.	Product Affinity Study: Which bank products or services are most commonly used together, and how might this influence cross-selling strategies?
use bank_crm;
WITH ProductUsage AS (
SELECT Customer_ID, NumOfProducts,
CASE 
WHEN NumOfProducts = 1 THEN 'SavingsAccount'
WHEN NumOfProducts = 2 THEN 'SavingsAccount, CreditCard'
WHEN NumOfProducts = 3 THEN 'SavingsAccount, CreditCard, Loan'
WHEN NumOfProducts >= 4 THEN 'SavingsAccount, CreditCard, Loan, InvestmentAccount'
END AS ProductCombination
from bank_churn 
),
CombinationAnalysis AS (
SELECT ProductCombination, COUNT(Customer_ID) AS CustomerCount
from ProductUsage
group by ProductCombination
)
SELECT ProductCombination, CustomerCount, ROUND(CustomerCount/(SELECT COUNT(*) FROM bank_churn) * 100, 2) AS PercentageOfCustomers
from CombinationAnalysis
order by CustomerCount DESC;

-- 3.	Geographic Market Trends: How do economic indicators in different geographic regions 
-- correlate with the number of active accounts and customer churn rates?
SELECT geo.GeographyLocation,COUNT(b.Exited) AS ChurnedCustomers,
(COUNT(DISTINCT b.Exited) / COUNT(DISTINCT c.Customer_ID)) * 100 AS ChurnRate
FROM geography geo
JOIN customer_info c ON geo.GeographyID = c.GeographyID
JOIN bank_churn b ON c.Customer_ID = b.Customer_ID
LEFT JOIN exitcustomer e ON b.Exited = e.Exit_ID
WHERE b.Exited = 1
GROUP BY geo.GeographyLocation;

-- 5. Customer Tenure Value Forecast: How would you use the available data to model and predict the lifetime (tenure) 
-- value in the bank of different customer segments?
SELECT c.Customer_ID,c.Age,c.EstimatedSalary,b.CreditScore,b.Tenure,b.Balance,b.NumOfProducts,
cc.Category AS CreditCardCategory,a.ActiveCategory,e.ExitCategory,ROUND(DATEDIFF(CURDATE(), c.Bank_DOJ) / 365,0) AS CurrentTenureYears
FROM customer_info c
JOIN geography geo ON c.GeographyID = geo.GeographyID
JOIN bank_churn b ON c.Customer_ID = b.Customer_ID
LEFT JOIN creditcard cc ON b.Has_creditcard = cc.CreditID
LEFT JOIN activecustomer a ON b.IsActiveMember = a.ActiveID
LEFT JOIN exitcustomer e ON b.Exited = e.Exit_ID;

-- 9.	Utilize SQL queries to segment customers based on demographics and account details

SELECT C.Customer_ID, C.Age,B.CreditScore,B.Balance,B.Tenure,G.GenderCategory,GO.GeographyLocation,
    CASE 
        WHEN C.Age < 25 THEN 'Youth (Under 25)'
        WHEN C.Age BETWEEN 25 AND 35 THEN 'Young Adults (25-35)'
        WHEN C.Age BETWEEN 36 AND 50 THEN 'Middle Age (36-50)'
        ELSE 'Senior (Above 50)'
    END AS AgeGroup,
    CASE 
        WHEN B.CreditScore < 500 THEN 'Poor Credit'
        WHEN B.CreditScore BETWEEN 500 AND 700 THEN 'Average Credit'
        ELSE 'Good Credit'
    END AS CreditScoreCategory,
    
    CASE 
        WHEN B.Balance < 10000 THEN 'Low Balance'
        WHEN B.Balance BETWEEN 10000 AND 50000 THEN 'Medium Balance'
        ELSE 'High Balance'
    END AS BalanceCategory,
    CASE 
        WHEN B.Tenure < 2 THEN 'New Customer'
        WHEN B.Tenure BETWEEN 2 AND 5 THEN 'Moderate Customer'
        ELSE 'Loyal Customer'
    END AS TenureSegment,
    CASE 
        WHEN Has_creditcard = 1 THEN 'Credit Card Holder'
        ELSE 'Non-Credit Card Holder'
    END AS CreditCardSegment
FROM bank_churn B
JOIN customer_info C on C.Customer_ID=B.Customer_ID
JOIN gender G on G.GenderID=C.GenderID
JOIN geography GO on GO.GeographyID=C.GeographyID;

-- 11.	What is the current churn rate per year and overall as well in the bank? Can you suggest some insights to the bank about which kind of customers are more likely to churn
--  and what different strategies can be used to decrease the churn rate?
use bank_crm;
-- Overall Churn Rate
SELECT (SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) AS OverallChurnRate
FROM bank_churn;

-- Churn Rate by Year
SELECT YEAR(Bank_DOJ) AS Year,
(SUM(CASE WHEN Exited = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) AS AnnualChurnRate
FROM bank_churn
JOIN customer_info ON bank_churn.Customer_Id = customer_info.Customer_Id
GROUP BY YEAR(Bank_DOJ);
